// Update Time and Date
function updateTime() {
    const now = new Date();
    
    // Format Time
    const optionsTime = { hour: 'numeric', minute: 'numeric', hour12: true };
    const timeStr = now.toLocaleTimeString('en-US', optionsTime);
    document.getElementById('time').textContent = timeStr;
    
    // Format Date
    const optionsDate = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const dateStr = now.toLocaleDateString('en-US', optionsDate);
    document.getElementById('date').textContent = dateStr;
    
    // Update Greeting based on time of day
    const hour = now.getHours();
    const greeting = document.getElementById('greeting');
    if (hour < 12) greeting.textContent = 'Good Morning!';
    else if (hour < 18) greeting.textContent = 'Good Afternoon!';
    else greeting.textContent = 'Good Evening!';
}

// Fetch a Motivational Quote (using a free API)
async function fetchQuote() {
    try {
        const response = await fetch('https://api.quotable.io/random?tags=motivational');
        const data = await response.json();
        document.getElementById('quote').textContent = `"${data.content}" — ${data.author}`;
    } catch (error) {
        console.error("Could not fetch quote:", error);
        document.getElementById('quote').textContent = '"The best way to get started is to quit talking and begin doing." — Walt Disney';
    }
}

// Run functions when the page loads
window.onload = function() {
    updateTime();
    fetchQuote();
    // Update the time every minute (60000 milliseconds)
    setInterval(updateTime, 60000);
};